import { ActivationHistory } from "@/components/activation-history"

export default function ActivationHistoryPage() {
  return (
    <div className="container py-6">
      <ActivationHistory />
    </div>
  )
}
