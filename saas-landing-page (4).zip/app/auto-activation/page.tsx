import { AutoActivationSettings } from "@/components/auto-activation-settings"

export default function AutoActivationPage() {
  return (
    <div className="container py-6">
      <AutoActivationSettings />
    </div>
  )
}
