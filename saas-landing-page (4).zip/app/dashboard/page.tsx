import { ActivationDashboard } from "@/components/activation-dashboard"

export default function DashboardPage() {
  return (
    <div className="container py-6">
      <ActivationDashboard />
    </div>
  )
}
