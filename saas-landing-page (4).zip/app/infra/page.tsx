import { InfraDashboard } from "@/components/infra-dashboard"

export default function InfraPage() {
  return <InfraDashboard />
}
