import { KaryawanDashboard } from "@/components/karyawan-dashboard"

export default function KaryawanPage() {
  return <KaryawanDashboard />
}
