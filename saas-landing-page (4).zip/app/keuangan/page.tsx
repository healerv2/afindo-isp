import { KeuanganDashboard } from "@/components/keuangan-dashboard"

export default function KeuanganPage() {
  return <KeuanganDashboard />
}
