import type React from "react"
export default function LoginSettingsLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
