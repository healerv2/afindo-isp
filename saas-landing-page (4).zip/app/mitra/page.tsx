import { MitraDashboard } from "@/components/mitra-dashboard"

export default function MitraPage() {
  return <MitraDashboard />
}
