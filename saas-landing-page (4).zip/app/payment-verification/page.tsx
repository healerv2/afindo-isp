import { PaymentVerification } from "@/components/payment-verification"

export default function PaymentVerificationPage() {
  return (
    <div className="container py-6">
      <PaymentVerification />
    </div>
  )
}
