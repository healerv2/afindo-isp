import { PelangganDashboard } from "@/components/pelanggan-dashboard"

export default function PelangganPage() {
  return <PelangganDashboard />
}
