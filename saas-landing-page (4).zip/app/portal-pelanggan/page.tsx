import { PortalPelangganDashboard } from "@/components/portal-pelanggan/dashboard"

export default function PortalPelangganPage() {
  return <PortalPelangganDashboard />
}
