import { PenggunaanDashboard } from "@/components/portal-pelanggan/penggunaan-dashboard"

export default function PenggunaanPage() {
  return <PenggunaanDashboard />
}
