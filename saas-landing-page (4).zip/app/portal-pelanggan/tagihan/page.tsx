import { TagihanDashboard } from "@/components/portal-pelanggan/tagihan-dashboard"

export default function TagihanPage() {
  return <TagihanDashboard />
}
