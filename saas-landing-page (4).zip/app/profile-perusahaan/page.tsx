import { ProfilePerusahaanDashboard } from "@/components/profile-perusahaan-dashboard"

export default function ProfilePerusahaanPage() {
  return <ProfilePerusahaanDashboard />
}
