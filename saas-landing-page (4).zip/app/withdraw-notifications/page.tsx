import { WithdrawNotification } from "@/components/withdraw-notification"

export default function WithdrawNotificationsPage() {
  return (
    <div className="container mx-auto py-6">
      <WithdrawNotification />
    </div>
  )
}
